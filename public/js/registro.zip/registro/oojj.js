$(function(){
	$('#sede_id').on('change', onSelectJuzgadoChange);
	//alert("Script Agregado");
});

function onSelectJuzgadoChange()
{
	var id_sede = $(this).val(); 
	
	if(!id_sede)
	{
		$('#oojj_id').html('<option value ="">-- Seleccionar Dependencia</option>');
		return;
	}

	//AJAX
	$.get('/cortelimaeste/api/juzgado/'+id_sede+'/sede', function(data){
		var html_select = '<option value ="">-- Seleccionar Dependencia</option>';
		
		for(var i=0; i<data.length; ++i)
		{
			html_select  += '<option value ="'+data[i].id+'">'+data[i].nombre+'</option>';
		}
		
		$('#oojj_id').html(html_select);
	});
}