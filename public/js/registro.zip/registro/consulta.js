$(function(){
	$('#tipo_consulta').on('change', onSelectConsultaChange);
	//alert("Script Agregado");
});

function onSelectConsultaChange()
{
	var id_consulta = $(this).val(); 
	
	if(!id_consulta)
	{
		$('#consulta_id').html('<option value ="">-- Seleccionar Consulta</option>');
		return;
	}

	//AJAX
	$.get('/cortelimaeste/api/tipo_consulta/'+id_consulta+'/consulta', function(data){
		var html_select = '<option value ="">-- Seleccionar Consulta</option>';
		
		for(var i=0; i<data.length; ++i)
		{
			html_select  += '<option value ="'+data[i].id+'">'+data[i].consulta+'</option>';
		}
		
		$('#consulta_id').html(html_select);
	});
}