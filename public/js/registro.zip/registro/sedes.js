$(function(){
	$('#distrito_id').on('change', onSelectDistritoChange);
	//alert("Script Agregado");
});

function onSelectDistritoChange()
{
	var id_sede = $(this).val();
	
	if(!id_sede)
	{
		$('#sede_id').html('<option value ="">-- Selecionar Sede </option>');
		$('#oojj_id').html('<option value ="">-- Seleccionar Dependencia </option>');
		return;
	}

	//AJAX
	$.get('/cortelimaeste/api/sede/'+id_sede+'/distrito', function(data){
		var html_select = '<option value ="">-- Selecionar Sede </option>';
		var html_select2 = '<option value ="">-- Seleccionar Dependencia</option>';

		for(var i=0; i<data.length; ++i)
		{
			html_select  += '<option value ="'+data[i].id+'">'+data[i].nombre+'</option>';
		}
		
		$('#sede_id').html(html_select);
		$('#oojj_id').html(html_select2);
	});
}